from setuptools import setup

setup(

	name="paqueteCalculos",
	version="1.0",
	description="paquete de redonde y potencia",
	author="Fernando",
	packages=["calculos","calculos.redondeo_potencia"]

	)