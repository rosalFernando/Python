def sumar(op1,op2):
	print("el resuldado de la suma es: ",op1+op2)

def restar(op1,op2):
	print("el resuldado de la resta es: ",op1-op2)

def multiplicar(op1,op2):
	print("el resuldado de la multiplacion es: ",op1*op2)

def dividir(dividendo,divisor):
	print("el resuldado de la division es: ",dividendo/divisor)

def potencia(base,exponente):
	print("la potencia de ",base," es: ",base**exponente)

def redondear(numero):
	print("el redonde de ",numero," es: ",round(numero))
