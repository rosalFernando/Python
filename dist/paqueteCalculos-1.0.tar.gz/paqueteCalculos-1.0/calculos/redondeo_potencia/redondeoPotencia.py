def potencia(base,exponente):
	print("la potencia de ",base," es: ",base**exponente)

def redondear(numero):
	print("el redonde de ",numero," es: ",round(numero))
